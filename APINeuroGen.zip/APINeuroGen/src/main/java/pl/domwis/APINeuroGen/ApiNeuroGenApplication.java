package pl.domwis.APINeuroGen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiNeuroGenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiNeuroGenApplication.class, args);
	}
}
